$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent (Split-Path -Parent (Split-Path -Parent $PSScriptRoot))
$source = Get-Content -Raw -LiteralPath (
    Join-Path $root 'btstack/profiles/btstack_classic_profiles.c')
$required = @(
    'sdp_init',
    'rfcomm_init',
    'btstack_a2dp_sink_setup',
    'btstack_avrcp_setup',
    'btstack_hfp_hf_setup',
    'gap_set_local_name',
    'gap_set_class_of_device',
    'gap_connectable_control',
    'gap_discoverable_control'
)
$missing = @($required | Where-Object { $source -notmatch [regex]::Escape($_) })
if ($missing.Count -ne 0) {
    $missing | ForEach-Object { Write-Host "Missing Classic setup: $_" }
    exit 1
}
Write-Host 'BTstack generic Classic Profile setup is present'
