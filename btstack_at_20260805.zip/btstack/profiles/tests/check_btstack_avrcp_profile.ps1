$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent (Split-Path -Parent (Split-Path -Parent $PSScriptRoot))
$source = Get-Content -Raw -LiteralPath (
    Join-Path $root 'btstack/profiles/btstack_avrcp.c')
$required = @(
    'avrcp_init',
    'avrcp_controller_init',
    'avrcp_target_init',
    'avrcp_register_packet_handler',
    'avrcp_controller_register_packet_handler',
    'avrcp_target_register_packet_handler',
    'avrcp_connect',
    'avrcp_disconnect',
    'AVRCP_SUBEVENT_CONNECTION_ESTABLISHED',
    'AVRCP_SUBEVENT_NOTIFICATION_PLAYBACK_STATUS_CHANGED',
    'AVRCP_SUBEVENT_NOW_PLAYING_INFO_DONE'
)
$missing = @($required | Where-Object { $source -notmatch [regex]::Escape($_) })
if ($missing.Count -ne 0) {
    $missing | ForEach-Object { Write-Host "Missing AVRCP implementation: $_" }
    exit 1
}
Write-Host 'BTstack generic AVRCP Profile implementation is present'
