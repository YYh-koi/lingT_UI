$ErrorActionPreference = 'Stop'

$root = Split-Path -Parent (Split-Path -Parent (Split-Path -Parent $PSScriptRoot))
$required = @(
    'btstack/profiles/btstack_classic_profiles.c',
    'btstack/profiles/btstack_avrcp.c',
    'btstack/include/profiles/btstack_classic_profiles.h',
    'btstack/include/profiles/btstack_avrcp.h',
    'btstack/at/btstack_at_backend.c'
)

$failures = @()
foreach ($relative in $required) {
    if (-not (Test-Path -LiteralPath (Join-Path $root $relative))) {
        $failures += "missing $relative"
    }
}

$portFiles = Get-ChildItem -LiteralPath (
    Join-Path $root 'btstack/ports/gpcv2178') -Filter '*.c' |
    Where-Object { $_.Name -ne 'btstack_hci_dump_gpcv2178.c' }
$forbiddenPortPatterns = @(
    '\bhfp_hf_',
    '\ba2dp_sink_',
    '\bavrcp_controller_',
    '\bhci_add_event_handler\s*\(',
    '\bhci_power_control\s*\(',
    'HCI_EVENT_HFP_META',
    'HCI_EVENT_A2DP_META',
    'HCI_EVENT_AVRCP_META',
    'HCI_EVENT_',
    'GAP_EVENT_'
)
foreach ($file in $portFiles) {
    $source = Get-Content -Raw -LiteralPath $file.FullName
    foreach ($pattern in $forbiddenPortPatterns) {
        if ($source -match $pattern) {
            $failures += "port contains generic Profile logic: $($file.Name) / $pattern"
        }
    }
}

$backendPath = Join-Path $root 'btstack/at/btstack_at_backend.c'
if (Test-Path -LiteralPath $backendPath) {
    $backend = Get-Content -Raw -LiteralPath $backendPath
    $forbiddenBackendPatterns = @(
        '\bhfp_hf_',
        '\ba2dp_sink_(establish_stream|disconnect)',
        '\bavrcp_controller_',
        'HCI_EVENT_HFP_META',
        'HCI_EVENT_A2DP_META',
        'HCI_EVENT_AVRCP_META'
    )
    foreach ($pattern in $forbiddenBackendPatterns) {
        if ($backend -match $pattern) {
            $failures += "AT backend calls raw Profile API: $pattern"
        }
    }
}

if ($failures.Count -ne 0) {
    $failures | ForEach-Object { Write-Host "FAIL: $_" }
    exit 1
}

Write-Host 'BTstack generic Profile layer boundary is clean'
