$ErrorActionPreference = 'Stop'

$root = Split-Path -Parent (Split-Path -Parent (Split-Path -Parent $PSScriptRoot))
$sourcePath = Join-Path $root 'btstack/at/btstack_at.c'

if (-not (Test-Path -LiteralPath $sourcePath)) {
    throw 'btstack/at/btstack_at.c is missing'
}

$source = Get-Content -Raw -LiteralPath $sourcePath
$checks = @(
    @{ Name = 'static input queue'; Pass = $source -match 'xQueueCreateStatic' },
    @{ Name = 'static AT task'; Pass = $source -match 'xTaskCreateStatic' },
    @{ Name = 'queue receive loop'; Pass = $source -match 'xQueueReceive' },
    @{ Name = 'zero-wait submit'; Pass = $source -match 'xQueueSend\s*\(\s*btstack_at_input_queue[^;]+0u\s*\)' },
    @{ Name = 'backend registration'; Pass = $source -match 'btstack_at_backend_register' },
    @{ Name = 'command gate registration'; Pass = $source -match 'btstack_at_command_gate_register' },
    @{ Name = 'command gate before backend'; Pass = $source -match 'btstack_at_command_gate\s*\(\s*&command' },
    @{ Name = 'handled command response'; Pass = $source -match 'BTSTACK_AT_GATE_HANDLED' },
    @{ Name = 'rejected command response'; Pass = $source -match 'BTSTACK_AT_GATE_REJECT' },
    @{ Name = 'completion ingress'; Pass = $source -match 'btstack_at_complete' },
    @{ Name = 'event ingress'; Pass = $source -match 'btstack_at_post_event' },
    @{ Name = 'asynchronous event drain'; Pass = $source -match 'BTSTACK_AT_EVENT_POLL_MS' -and $source -notmatch 'btstack_at_input_queue,\s*&item,\s*portMAX_DELAY' },
    @{ Name = 'state event deduplication'; Pass = $source -match 'btstack_at_event_is_state' -and $source -match 'btstack_at_last_state_event' },
    @{ Name = 'no heap allocation'; Pass = $source -notmatch 'pvPortMalloc|malloc\s*\(' }
)

$failed = @($checks | Where-Object { -not $_.Pass })
if ($failed.Count -ne 0) {
    foreach ($check in $failed) {
        Write-Error "Missing: $($check.Name)"
    }
    exit 1
}

$callbackCalls = [regex]::Matches(
    $source,
    'btstack_at_config\.output_callback\s*\(').Count
if ($callbackCalls -ne 1) {
    throw "output callback call sites=$callbackCalls, expected 1"
}

Write-Host 'BTstack AT task ownership and static resource contract is present'
