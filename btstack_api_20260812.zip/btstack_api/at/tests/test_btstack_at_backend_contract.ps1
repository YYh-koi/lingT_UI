$ErrorActionPreference = 'Stop'

$root = Split-Path -Parent (Split-Path -Parent (Split-Path -Parent $PSScriptRoot))
$sourcePath = Join-Path $root 'btstack/at/btstack_at_backend.c'
$headerPath = Join-Path $root 'btstack/at/btstack_at_backend.h'

if (-not (Test-Path -LiteralPath $sourcePath)) {
    throw 'Generic AT backend source is missing'
}
if (-not (Test-Path -LiteralPath $headerPath)) {
    throw 'Generic AT backend header is missing'
}

$source = Get-Content -Raw -LiteralPath $sourcePath
$generalCommands = @(
    'PROFILE','VER','BTEN','ADDR','NAME','PIN','SSP','CFM','PAIR','PAGE',
    'COD','PLIST','TDL','SCAN','DSCA','MICMUTE','SPKVOL'
)
$hfpCommands = @(
    'HFPCFG','HFPSTAT','HFPCONN','HFPDISC','HFPDIAL','HFPDTMF',
    'HFPANSW','HFPCHUP','HFPMCAL','HFPADTS','HFPVR'
)
$a2dpCommands = @('A2DPSTAT','A2DPCONN','A2DPDISC','A2DPMUTE')
$avrcpCommands = @(
    'AVRCPCFG','PLAYPAUSE','PLAY','PAUSE','STOP','NEXT','PREV',
    'FORWARD','BACKWARD','REPEAT','SHUFFLE','SABSUP','SABSDOWN'
)

$checks = @(
    @{ Name = 'run-loop callback registration'; Pass = $source -match 'btstack_context_callback_registration_t' },
    @{ Name = 'main-thread dispatch'; Pass = $source -match 'btstack_run_loop_execute_on_main_thread' },
    @{ Name = 'backend registration'; Pass = $source -match 'btstack_at_backend_register' },
    @{ Name = 'eight RAM peers'; Pass = $source -match 'BTSTACK_AT_PEER_MAX' },
    @{ Name = 'GAP event registration'; Pass = $source -match 'btstack_gap_set_event_callback' },
    @{ Name = 'generic event router publishing'; Pass = $source -match 'bt_xstack_event_router_publish' },
    @{ Name = 'table-driven command domain lookup'; Pass = $source -match 'btstack_at_command_get_domain' },
    @{ Name = 'no chained domain probing'; Pass = $source -notmatch 'status\s*==\s*1' },
    @{ Name = 'no direct AT event queue publishing'; Pass = $source -notmatch 'btstack_at_post_event\s*\(' },
    @{ Name = 'no direct manager power notification'; Pass = $source -notmatch 'bt_xstack_manager_on_power_state\s*\(' },
    @{ Name = 'Classic inquiry'; Pass = $source -match 'btstack_gap_scan_start' -and $source -match 'btstack_gap_scan_stop' },
    @{ Name = 'SSP confirmation'; Pass = $source -match 'btstack_gap_pairing_confirm' },
    @{ Name = 'PIN configuration'; Pass = $source -match 'btstack_gap_set_pin' },
    @{
        Name = 'default connectable policy'
        Pass = $source -match 'btstack_gap_set_connectable\s*\(\s*true\s*\)'
    },
    @{
        Name = 'default discoverable policy'
        Pass = $source -match 'btstack_gap_set_discoverable\s*\(\s*true\s*\)'
    }
)

foreach ($command in $generalCommands) {
    $checks += @{
        Name = "command $command"
        Pass = $source -match "BTSTACK_AT_COMMAND_$command"
    }
}
foreach ($command in $hfpCommands) {
    $checks += @{
        Name = "HFP command $command"
        Pass = $source -match "case\s+BTSTACK_AT_COMMAND_$command\s*:"
    }
}
foreach ($command in $a2dpCommands) {
    $checks += @{
        Name = "A2DP command $command"
        Pass = $source -match "case\s+BTSTACK_AT_COMMAND_$command\s*:"
    }
}
foreach ($command in $avrcpCommands) {
    $checks += @{
        Name = "AVRCP command $command"
        Pass = $source -match "case\s+BTSTACK_AT_COMMAND_$command\s*:"
    }
}

$hfpApis = @(
    'btstack_hfp_hf_connect',
    'btstack_hfp_hf_disconnect',
    'btstack_hfp_hf_dial_number',
    'btstack_hfp_hf_redial',
    'btstack_hfp_hf_send_dtmf',
    'btstack_hfp_hf_control'
)
foreach ($api in $hfpApis) {
    $checks += @{
        Name = "HFP API $api"
        Pass = $source -match $api
    }
}

$checks += @{
    Name = 'HFP structured event registration'
    Pass = $source -match 'btstack_hfp_hf_set_profile_event_callback'
}
$a2dpAvrcpApis = @(
    'btstack_a2dp_sink_connect',
    'btstack_a2dp_sink_disconnect',
    'btstack_avrcp_connect',
    'btstack_avrcp_control',
    'btstack_avrcp_set_repeat',
    'btstack_avrcp_set_shuffle'
)
foreach ($api in $a2dpAvrcpApis) {
    $checks += @{
        Name = "A2DP/AVRCP API $api"
        Pass = $source -match $api
    }
}
$checks += @{
    Name = 'A2DP structured event registration'
    Pass = $source -match 'btstack_a2dp_sink_set_event_callback'
}
$checks += @{
    Name = 'A2DP PCM configuration event'
    Pass = $source -match 'case\s+BTSTACK_A2DP_SINK_EVENT_PCM_CONFIG\s*:' -and
           $source -match 'BTSTACK_AT_EVENT_A2DPPCMCONFIG' -and
           $source -match 'event\.values\[0\]\s*=\s*profile_event->sample_rate' -and
           $source -match 'event\.values\[1\]\s*=\s*profile_event->channel_count' -and
           $source -match 'event\.values\[2\]\s*=\s*profile_event->bits_per_sample' -and
           $source -match 'event\.value_count\s*=\s*3u'
}
$checks += @{
    Name = 'AVRCP structured event registration'
    Pass = $source -match 'btstack_avrcp_set_event_callback'
}

$forbiddenGapPatterns = @(
    '\bhci_add_event_handler\s*\(',
    '\bhci_event_[A-Za-z0-9_]+\s*\(',
    '\bgap_event_[A-Za-z0-9_]+\s*\(',
    '(?<!btstack_)\bgap_[A-Za-z0-9_]+\s*\(',
    '\bhci_power_control\s*\('
)
foreach ($pattern in $forbiddenGapPatterns) {
    $checks += @{
        Name = "no native GAP/HCI dependency $pattern"
        Pass = $source -notmatch $pattern
    }
}

$failed = @($checks | Where-Object { -not $_.Pass })
if ($failed.Count -ne 0) {
    foreach ($check in $failed) {
        Write-Error "Missing: $($check.Name)"
    }
    exit 1
}

Write-Host 'Generic AT General/GAP/Profile backend contract is present'
