$ErrorActionPreference = 'Stop'

$root = Split-Path -Parent (Split-Path -Parent (Split-Path -Parent $PSScriptRoot))
$headerPath = Join-Path $root 'btstack/events/bt_xstack_event_router.h'
$sourcePath = Join-Path $root 'btstack/events/bt_xstack_event_router.c'

foreach ($path in @($headerPath, $sourcePath)) {
    if (-not (Test-Path -LiteralPath $path)) {
        throw "Missing xStack Event Router file: $path"
    }
}

$header = Get-Content -Raw -LiteralPath $headerPath
$source = Get-Content -Raw -LiteralPath $sourcePath
$combined = $header + "`n" + $source

foreach ($required in @(
        'bt_xstack_event_t',
        'bt_xstack_event_router_init',
        'bt_xstack_event_router_reset',
        'bt_xstack_event_router_register',
        'bt_xstack_event_router_publish')) {
    if ($combined -notmatch $required) {
        throw "Missing Event Router contract: $required"
    }
}

if ($source -notmatch '#define\s+BT_XSTACK_EVENT_SINK_MAX\s+4u') {
    throw 'Event Router capacity must be four static sinks'
}
if ($source -notmatch 'btstack_port_ops_get_ops') {
    throw 'Event Router must use the registered port critical callbacks'
}
if ($source -match '\b(?:malloc|calloc|realloc|free)\s*\(') {
    throw 'Event Router must not use heap memory'
}
if ($source -notmatch 'snapshot\s*\[\s*BT_XSTACK_EVENT_SINK_MAX\s*\]') {
    throw 'Event Router must copy a local sink snapshot before callbacks'
}
if ($source -notmatch '(?s)snapshot.*?bt_xstack_event_router_exit_critical\s*\(\s*\).*?\.sink\s*\(') {
    throw 'Event Router callbacks must execute after leaving the critical section'
}
if ($source -notmatch '(?s)entry->sink\s*==\s*sink.*?entry->context\s*==\s*context.*?BTSTACK_STATUS_OK') {
    throw 'Duplicate sink/context registration must be idempotent'
}
if ($source -notmatch 'BTSTACK_STATUS_INVALID_ARGUMENT') {
    throw 'Event Router must reject null arguments'
}
if ($source -notmatch 'BTSTACK_STATUS_NO_MEMORY') {
    throw 'Event Router must report full capacity'
}

Write-Host 'xStack fixed-capacity Event Router contract is present'
