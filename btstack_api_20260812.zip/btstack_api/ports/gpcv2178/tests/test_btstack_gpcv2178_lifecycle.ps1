$ErrorActionPreference = 'Stop'

$root = Split-Path -Parent (Split-Path -Parent (Split-Path -Parent (Split-Path -Parent $PSScriptRoot)))
$headerPath = Join-Path $root 'btstack/ports/gpcv2178/btstack_gpcv2178_port.h'
$sourcePath = Join-Path $root 'btstack/ports/gpcv2178/btstack_gpcv2178_port.c'
$header = Get-Content -Raw -LiteralPath $headerPath
$source = Get-Content -Raw -LiteralPath $sourcePath

$checks = @(
    @{ Name = 'port init API'; Pass = $header -match 'int\s+btstack_gpcv2178_init\s*\(void\)' },
    @{ Name = 'run loop start API'; Pass = $header -match 'int\s+btstack_gpcv2178_start_run_loop\s*\(void\)' },
    @{ Name = 'run loop state API'; Pass = $header -match 'int\s+btstack_gpcv2178_run_loop_started\s*\(void\)' },
    @{ Name = 'HCI setup in init'; Pass = $source -match 'int\s+btstack_gpcv2178_init\s*\(void\)[\s\S]+hci_init\s*\(' },
    @{ Name = 'L2CAP setup in init'; Pass = $source -match 'int\s+btstack_gpcv2178_init\s*\(void\)[\s\S]+l2cap_init\s*\(' },
    @{ Name = 'profiles setup in init'; Pass = $source -match 'int\s+btstack_gpcv2178_init\s*\(void\)[\s\S]+btstack_classic_profiles_setup\s*\(' },
    @{ Name = 'AT backend setup in init'; Pass = $source -match 'int\s+btstack_gpcv2178_init\s*\(void\)[\s\S]+btstack_at_backend_init\s*\(' },
    @{ Name = 'run-loop-only task'; Pass = $source -match 'static\s+void\s+btstack_gpcv2178_task[\s\S]+btstack_run_loop_execute\s*\(\)' },
    @{ Name = 'no automatic power on'; Pass = $source -notmatch 'btstack_gap_set_power\s*\(\s*true\s*\)' }
)

$failed = @($checks | Where-Object { -not $_.Pass })
if ($failed.Count -ne 0) {
    foreach ($check in $failed) {
        Write-Error "Missing: $($check.Name)"
    }
    exit 1
}

Write-Host 'GPCV2178 BTstack initialization and run-loop lifecycle are separated'
