# BTstack Adapter Layer

The BTstack adapter layer lives in top-level directories beside `src`. It keeps
protocol-stack glue, GAP helpers, profile facades, event routing, local property
handling, advertising data building, and bond/device records separate from
board, chip, product, scheduler, and storage implementations.

## Directory Layout

- `adapter/`: stack adapter entry, port operation registration, property store,
  make source list, and this README.
- `events/`: unified upstream event queue and app callback dispatch.
- `gap/`: GAP-facing helpers for advertising, scanning, link/pairing/security,
  privacy, and AD/EIR data building.
- `transport/`: generic HCI transport interfaces and helpers such as H4, H5,
  USB, SPI, UART, and SLIP.
- `profiles/`: generic HID Device, HOGP Device, GATT, A2DP Sink, and HFP HF
  front-end logic.
- `include/`: public headers for adapter, events, GAP, and profile APIs.
- `tools/check_adapter_boundary.ps1`: guard script that rejects known customer
  SDK dependency markers.
- `tools/check_adapter_migration.ps1`: migration guard for legacy directory and
  symbol names.

Removed legacy directories and target templates are intentionally not part of
this layer. Port folders for concrete products can be added later beside `src`
when the target SDK integration starts.

## Integration Steps

1. Keep `adapter`, `events`, `gap`, `profiles`, `transport`, and `include`
   beside `src`.
2. Add `include`, `include/adapter`, `src`, and `transport` to the compiler
   include paths when building the full stack.
3. Compile the source files listed in `adapter/Makefile.inc` and
   `transport/Makefile.inc`.
4. Override feature macros from `include/adapter/btstack_config.h` in the target
   build when a transport or profile is required.
5. Implement `btstack_port_ops_t` for the target board/OS, then call
   `btstack_port_ops_set_ops()` before `btstack_adapter_setup()`.
6. Bind link, ATT database emission, SCO/audio paths, media streams, storage,
   and HCI command transport in the target backend.

## Layer Boundary

The adapter layer provides initialization order, feature switches, bounded data
ownership, GAP helper state, event queueing, profile facade state, and
storage-facing device/bond records. The transport layer owns generic HCI packet
framing and UART/SLIP-facing interfaces. Ports own controller drivers, OS tasks,
power/reset, and concrete UART/SPI/USB implementations.

Default feature macros keep optional profiles disabled. Disabled setup and
control paths return `BTSTACK_STATUS_NOT_SUPPORTED`. When a profile is enabled
but no target backend has been bound, setup functions may store generic
configuration, while link, media, telephony, database emission, and value
transport operations return `BTSTACK_STATUS_NOT_SUPPORTED` or
`BTSTACK_STATUS_NOT_READY`.

## Event Dispatch

Protocol-stack callbacks should post normalized events with `btstack_event_post`
or profile-specific notify helpers. The event module copies bounded payloads
into a queue and signals the event-worker hook when the port provides one.
The application callback is then executed by that worker through
`btstack_event_process()`, so BTstack's run loop is not held by upper-layer app
logic. If no worker hook is installed, dispatch falls back to synchronous
processing for bring-up.

## Bonding And Reconnect

Bonding is persistent pairing state: peer address, address type, transport, and
opaque key material are stored through the port storage callbacks. Reconnect is
the later use of that stored peer identity to select a known device or start a
backend-owned connection flow. `btstack_property.c` manages records and the
selected active bond id; the target backend decides how those records are
applied to controller or host stack procedures.

## Port Responsibilities

A target port should provide the operations it needs from
`btstack_port_ops_t`:

- Critical section enter and exit, if callbacks can arrive from multiple
  contexts.
- Event worker signalling or scheduling, so app callbacks run outside the
  BTstack run loop.
- Key-value storage read, write, and delete callbacks for device properties and
  bond records.
- Random static address generation when BLE random addresses are desired.
- Controller address application for Classic and BLE transports.
- HCI transport binding, such as selecting H4/H5 and passing the target UART
  driver into the generic transport instance.

Missing optional port operations keep the adapter layer conservative: events can
fall back to synchronous processing, and properties remain in RAM unless stored
through a provided backend.

## Verification

Run the guards before copying or publishing changes:

```powershell
powershell -ExecutionPolicy Bypass -File tools/check_adapter_migration.ps1
powershell -ExecutionPolicy Bypass -File tools/check_adapter_boundary.ps1
```

The scripts scan adapter C headers, C sources, markdown, make metadata, and tool
scripts for legacy names and known customer SDK dependency markers.
