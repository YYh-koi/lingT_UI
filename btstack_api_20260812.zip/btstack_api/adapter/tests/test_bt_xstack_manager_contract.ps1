$ErrorActionPreference = 'Stop'

$root = Split-Path -Parent (Split-Path -Parent (Split-Path -Parent $PSScriptRoot))
$headerPath = Join-Path $root 'btstack/include/adapter/bt_xstack.h'
$deliveryHeaderPath = Join-Path $root 'gplib/liba_wifi_src/atbm/atbm6165/bt/bt_xstack.h'
$managerPath = Join-Path $root 'btstack/adapter/bt_xstack_manager.c'
$internalPath = Join-Path $root 'btstack/adapter/bt_xstack_manager_internal.h'
$forbiddenPath = Join-Path $root 'btstack/adapter/bt_xstack.c'

function Assert-Match {
    param([string]$Text, [string]$Pattern, [string]$Message)
    if ($Text -notmatch $Pattern) {
        throw $Message
    }
}

function Assert-NotMatch {
    param([string]$Text, [string]$Pattern, [string]$Message)
    if ($Text -match $Pattern) {
        throw $Message
    }
}

foreach ($path in @($headerPath, $deliveryHeaderPath, $managerPath, $internalPath)) {
    if (-not (Test-Path -LiteralPath $path)) {
        throw "Missing required file: $path"
    }
}
if (Test-Path -LiteralPath $forbiddenPath) {
    throw 'bt_xstack.c must not exist; use bt_xstack_manager.c'
}

$header = Get-Content -Raw -LiteralPath $headerPath
$deliveryHeader = Get-Content -Raw -LiteralPath $deliveryHeaderPath
$manager = Get-Content -Raw -LiteralPath $managerPath
$internal = Get-Content -Raw -LiteralPath $internalPath

Assert-Match $header 'typedef\s+void\s*\(\s*\*bt_event_callback_t\s*\)' 'Missing bt_event_callback_t'
Assert-Match $header 'int\s+bt_xstack_init\s*\(' 'Missing bt_xstack_init'
Assert-Match $header 'int\s+bt_xstack_send_at\s*\(' 'Missing bt_xstack_send_at'
foreach ($publicHeader in @($header, $deliveryHeader)) {
    Assert-Match $publicHeader 'typedef\s+void\s*\(\s*\*bt_xstack_pcm_callback_t\s*\)\s*\(\s*const\s+uint8_t\s*\*\s*data\s*,\s*uint32_t\s+len\s*\)' 'Missing bt_xstack_pcm_callback_t'
    Assert-Match $publicHeader 'int\s+bt_xstack_a2dp_register_pcm_callback\s*\(\s*bt_xstack_pcm_callback_t\s+callback\s*\)' 'Missing bt_xstack_a2dp_register_pcm_callback'
    Assert-NotMatch $publicHeader 'bt_xstack_a2dp_get_pcm_config' 'PCM config getter must not be public'
}
Assert-NotMatch $header '(?i)atbm|gpcv2178' 'Public API must be platform-neutral'

foreach ($state in @(
    'BT_XSTACK_STATE_UNINITIALIZED',
    'BT_XSTACK_STATE_AT_READY',
    'BT_XSTACK_STATE_RUN_LOOP_STARTED',
    'BT_XSTACK_STATE_POWERED',
    'BT_XSTACK_STATE_FAILED')) {
    Assert-Match $manager $state "Missing manager state: $state"
}

Assert-Match $manager 'btstack_gpcv2178_init' 'Manager must initialize the platform port'
Assert-Match $manager 'btstack_at_init' 'Manager must initialize the AT frontend'
Assert-Match $manager 'btstack_at_command_gate_register' 'Manager must register the AT command gate'
Assert-Match $manager 'btstack_at_start' 'Manager must start the AT task'
Assert-Match $manager 'BTSTACK_AT_COMMAND_BTEN' 'Manager gate must handle BTEN'
Assert-Match $manager 'btstack_at_submit' 'Manager send API must submit to the AT queue'
Assert-Match $manager 'btstack_a2dp_sink_set_audio_sample_callback\s*\(\s*bt_xstack_pcm_bridge\s*\)' 'Manager must install the PCM bridge'
Assert-Match $manager 'int\s+bt_xstack_a2dp_register_pcm_callback\s*\(' 'Manager must implement PCM registration'
Assert-Match $manager 'bt_xstack_event_router_register\s*\(' 'Manager must register an internal event sink'
Assert-Match $manager 'BT_XSTACK_EVENT_PWRSTAT' 'Manager sink must consume the routed power event'
Assert-NotMatch $manager 'void\s+bt_xstack_manager_on_power_state\s*\(' 'Manager must not expose a Backend-owned power callback'
Assert-NotMatch $internal 'bt_xstack_manager_on_power_state' 'Internal header still exposes the old power callback'

Write-Host 'BT xStack public API and manager contract is present'
