# Audited BTstack local patches

The sources under `btstack_api/src` use BTstack v1.6.2 as their upstream base.
Files other than the entries documented here remain byte-for-byte upstream and
are checked by the offline SHA-256 manifest.

`src/classic/pbap_client.c` carries one local status-preservation patch:
`btstack-1.6.2-pbap-preserve-obex-status.patch`. It preserves PBAP PullPhoneBook
OBEX response semantics for the wrapper: not-found remains `OBEX_NOT_FOUND`,
and unauthorized/forbidden become `ERROR_CODE_AUTHENTICATION_FAILURE`. Unknown
responses retain the upstream `OBEX_UNKNOWN_ERROR` fallback.

- BTstack v1.6.2 base SHA-256: `0e7ed47854273b0424f45225740a52a21d701a0d076b1ad2af79ff42c55f2cb4`
- Patched SHA-256: `18b2de664a3f30ebe14856ae3d096b382a543ae09377249335de8cd2e4d812c1`

The upstream contract verifies both the patched hash and the exact response
mapping shape, while leaving every other upstream SHA unchanged.

The contract also copies the checked-in patched source to a temporary tree and
runs `git apply --check --reverse`, reverse-applies the patch to verify the base
SHA-256, then forward-checks and applies it to verify the patched SHA-256. The
upstream v1.6.2 file ends without a final newline while the checked-in patched
artifact has one, so the standard unified diff intentionally records Git's
`No newline at end of file` marker as part of the reproducible byte transition.
