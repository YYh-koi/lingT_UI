$ErrorActionPreference = 'Stop'

$root = Resolve-Path (Join-Path $PSScriptRoot '..\..')
$backendPath = Join-Path $root 'api\bt_xstack_api_backend.c'
$corePath = Join-Path $root 'api\bt_xstack_api_core.c'
$backend = Get-Content -LiteralPath $backendPath -Raw
$core = Get-Content -LiteralPath $corePath -Raw

function Assert-Contains {
    param([string]$Text, [string]$Pattern, [string]$Message)
    if ($Text.IndexOf($Pattern, [System.StringComparison]::Ordinal) -lt 0) {
        throw $Message
    }
}

function Assert-NotContains {
    param([string]$Text, [string]$Pattern, [string]$Message)
    if ($Text.IndexOf($Pattern, [System.StringComparison]::Ordinal) -ge 0) {
        throw $Message
    }
}

function Get-Section {
    param([string]$Text, [string]$Start, [string]$End)
    $startIndex = $Text.IndexOf($Start, [System.StringComparison]::Ordinal)
    if ($startIndex -lt 0) { throw "Missing section start: $Start" }
    $endIndex = $Text.IndexOf($End, $startIndex + $Start.Length,
        [System.StringComparison]::Ordinal)
    if ($endIndex -lt 0) { throw "Missing section end: $End" }
    return $Text.Substring($startIndex, $endIndex - $startIndex)
}

$local = Get-Section $backend `
    'static int bt_xstack_api_execute_local_request' `
    'static int bt_xstack_api_prepare_stack_request'
$prepare = Get-Section $backend `
    'static int bt_xstack_api_prepare_stack_request' `
    'static int bt_xstack_api_execute_stack_request'
$stack = Get-Section $backend `
    'static int bt_xstack_api_execute_stack_request' `
    'static void bt_xstack_api_execute'
$runLoopCallback = Get-Section $backend `
    'static void bt_xstack_api_execute' `
    'int bt_xstack_api_backend_dispatch'
$dispatch = $backend.Substring($backend.IndexOf(
    'int bt_xstack_api_backend_dispatch',
    [System.StringComparison]::Ordinal))

$localRequests = @(
    'BT_XSTACK_REQUEST_SET_PROFILE_MASK',
    'BT_XSTACK_REQUEST_CLEAR_PEER_INDEX',
    'BT_XSTACK_REQUEST_CLEAR_PEER_ADDRESS',
    'BT_XSTACK_REQUEST_CLEAR_PEERS',
    'BT_XSTACK_REQUEST_SET_TDL',
    'BT_XSTACK_REQUEST_SET_HFP_CONFIG',
    'BT_XSTACK_REQUEST_SET_MICROPHONE_MUTE',
    'BT_XSTACK_REQUEST_SET_A2DP_MUTE'
)
foreach ($requestId in $localRequests) {
    Assert-Contains $local $requestId `
        "$requestId must execute in API task context"
    Assert-NotContains $stack $requestId `
        "$requestId must not execute on the BTstack run loop"
}

Assert-Contains $prepare 'BT_XSTACK_REQUEST_SET_NAME' `
    'Local-name formatting must occur during API-task preparation'
Assert-Contains $prepare 'BT_XSTACK_REQUEST_CONNECT_LAST' `
    'Cached peer resolution must occur during API-task preparation'
Assert-Contains $prepare 'BT_XSTACK_HFP_CONTROL_TOGGLE_AUDIO' `
    'HFP toggle selection must occur during API-task preparation'
Assert-Contains $prepare 'BT_XSTACK_AVRCP_CONTROL_PLAY_PAUSE' `
    'AVRCP play/pause selection must occur during API-task preparation'
Assert-Contains $prepare 'bt_xstack_api_event_set_scan_filter' `
    'Scan filter must be copied before entering the run loop'

foreach ($forbidden in @(
    'strlen(',
    'bt_xstack_api_backend_copy_state',
    'bt_xstack_api_event_set_scan_filter',
    'bt_xstack_api_state_get_profile_peer',
    'bt_xstack_api_state_set_profile_peer')) {
    Assert-NotContains $stack $forbidden `
        "Run-loop stack executor contains preparation work: $forbidden"
}

$prepareIndex = $dispatch.IndexOf(
    'bt_xstack_api_prepare_stack_request',
    [System.StringComparison]::Ordinal)
$scheduleIndex = $dispatch.IndexOf(
    'btstack_run_loop_gpcv2178_enqueue_callback',
    [System.StringComparison]::Ordinal)
if (($prepareIndex -lt 0) -or ($scheduleIndex -lt 0) -or
    ($prepareIndex -ge $scheduleIndex)) {
    throw 'Stack request must be fully prepared before run-loop scheduling'
}

Assert-NotContains $dispatch 'bt_xstack_api_complete' `
    'Local and rejected requests must not synthesize command completion'
Assert-Contains $runLoopCallback 'bt_xstack_api_execute_stack_request' `
    'Run-loop callback must invoke only the prepared stack executor'
Assert-NotContains $runLoopCallback 'bt_xstack_api_state_sync_gap' `
    'Run-loop callback must not perform unconditional GAP synchronization'

$getterMatch = [regex]::Match($core,
    'bt_xstack_result_t\s+bt_xstack_get_avrcp_play_state\s*\([^\{]+\)\s*\{[^\}]+\}')
if (-not $getterMatch.Success) {
    throw 'AVRCP play-state Getter definition not found'
}
Assert-Contains $getterMatch.Value 'bt_xstack_api_read_avrcp_snapshot' `
    'AVRCP play-state Getter must use the compact protected AVRCP snapshot'
Assert-NotContains $getterMatch.Value 'bt_xstack_api_snapshot' `
    'AVRCP play-state Getter must not copy the complete cached state'
Assert-NotContains $getterMatch.Value 'bt_xstack_api_submit' `
    'Synchronous Getter must not schedule the BTstack run loop'

Write-Host 'xStack API prepares requests before the minimal run-loop boundary'
