$ErrorActionPreference = 'Stop'

$root = Resolve-Path (Join-Path $PSScriptRoot '..\..')
$core = Get-Content -LiteralPath (Join-Path $root 'api\bt_xstack_api_core.c') -Raw
$internal = Get-Content -LiteralPath (Join-Path $root 'api\bt_xstack_api_internal.h') -Raw

function Require([string]$Text, [string]$Pattern, [string]$Message) {
    if ($Text -notmatch $Pattern) { throw $Message }
}
function Forbid([string]$Text, [string]$Pattern, [string]$Message) {
    if ($Text -match $Pattern) { throw $Message }
}

Require $internal 'BT_XSTACK_CRITICAL_EVENT_QUEUE_LEN\s+16u' `
    'Critical control events need a dedicated fixed queue'
Require $internal 'BT_XSTACK_BEST_EFFORT_EVENT_QUEUE_LEN\s+16u' `
    'Scan results need a dedicated best-effort queue'
Require $internal 'BT_XSTACK_EVENT_TASK_STACK_WORDS\s+1024u' `
    'Event dispatcher must use a fixed static task stack'

foreach ($name in @(
        'bt_xstack_critical_event_queue',
        'bt_xstack_best_effort_event_queue',
        'bt_xstack_event_task_handle',
        'bt_xstack_event_task_stack',
        'bt_xstack_critical_event_drop_count',
        'bt_xstack_best_effort_event_drop_count')) {
    Require $core $name "Missing event-dispatch state: $name"
}
Require $core 'static\s+void\s+bt_xstack_event_task\s*\(' `
    'Control callbacks need an independent event task'
Require $core 'xTaskNotifyGive\s*\(\s*bt_xstack_event_task_handle\s*\)' `
    'Posting an event must immediately wake the event task'
Require $core 'ulTaskNotifyTake\s*\(\s*pdTRUE\s*,\s*portMAX_DELAY\s*\)' `
    'Event task must block on notification instead of polling'
Require $core `
    'BT_XSTACK_SERVICE_EVENT_SCAN_RESULT[\s\S]*?bt_xstack_best_effort_event_queue' `
    'Only scan results must use the best-effort event queue'
Require $core `
    'xQueueReceive\s*\(\s*bt_xstack_critical_event_queue[\s\S]*?xQueueReceive\s*\(\s*bt_xstack_best_effort_event_queue' `
    'Event task must drain critical events before best-effort scan results'

Forbid ($core + "`n" + $internal) 'BT_XSTACK_API_EVENT_POLL_MS' `
    'Fixed 20 ms event polling must be removed'
Forbid $core 'bt_xstack_event_queue\b' `
    'The old shared control-event queue must be removed'

Write-Host 'xStack control events use an independent notification-driven dispatcher'
