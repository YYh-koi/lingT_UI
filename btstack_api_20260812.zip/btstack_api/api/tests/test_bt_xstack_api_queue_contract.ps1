$ErrorActionPreference = 'Stop'

$apiRoot = Split-Path -Parent $PSScriptRoot
$internalPath = Join-Path $apiRoot 'bt_xstack_api_internal.h'
$corePath = Join-Path $apiRoot 'bt_xstack_api_core.c'

if (-not (Test-Path -LiteralPath $internalPath)) {
    throw 'Missing API internal request model'
}
if (-not (Test-Path -LiteralPath $corePath)) {
    throw 'Missing API core implementation'
}

$internal = Get-Content -Raw -LiteralPath $internalPath
$core = Get-Content -Raw -LiteralPath $corePath

function Assert-Match([string]$text, [string]$pattern, [string]$message) {
    if ($text -notmatch $pattern) { throw $message }
}
function Assert-NoMatch([string]$text, [string]$pattern, [string]$message) {
    if ($text -match $pattern) { throw $message }
}

Assert-Match $internal 'BT_XSTACK_REQUEST_QUEUE_LEN\s+8u' `
    'Request queue length must remain eight'
Assert-Match $internal 'BT_XSTACK_EVENT_QUEUE_LEN\s+16u' `
    'Event queue length must remain sixteen'
Assert-Match $internal `
    'BT_XSTACK_COMMAND_SLOT_COUNT\s+BT_XSTACK_REQUEST_QUEUE_LEN' `
    'Command slot pool must cover every admitted request'
Assert-Match $internal 'char\s+text\s*\[\s*BT_XSTACK_TEXT_MAX\s*\]' `
    'Requests must own text storage'
Assert-Match $internal 'bt_xstack_addr_t\s+address\s*;' `
    'Requests must own address storage'

Assert-Match $core 'xQueueCreateStatic\s*\(' `
    'API core must use static queues'
Assert-Match $core 'xTaskCreateStatic\s*\(' `
    'API core must use a static worker task'
Assert-Match $core 'xQueueSend\s*\(' `
    'API requests must use task-context queue submission'
Assert-Match $core 'memcpy\s*\(' `
    'API request values must be copied before queueing'
Assert-Match $core 'BT_XSTACK_BACKEND_BUSY' `
    'Worker must wait and retry when all prepared-command slots are occupied'
Assert-NoMatch $core 'BT_XSTACK_EXEC_TIMEOUT_MS' `
    'Individual commands must not rely on a global-failure completion timeout'
Assert-NoMatch $core 'FromISR' `
    'API front end must not expose an ISR submission path'
Assert-NoMatch $core '\bmalloc\s*\(' `
    'API core must not allocate from the heap'
Assert-NoMatch $core '\bfree\s*\(' `
    'API core must not allocate from the heap'
Assert-NoMatch $core '\bbtstack_at_' `
    'API core must not depend on the AT front end'

Write-Output 'xStack API uses static task-context request and event queues'
