$ErrorActionPreference = 'Stop'

$apiRoot = Split-Path -Parent $PSScriptRoot
$backendPath = Join-Path $apiRoot 'bt_xstack_api_backend.c'
$eventPath = Join-Path $apiRoot 'bt_xstack_api_event.c'
if (-not (Test-Path -LiteralPath $backendPath)) {
    throw 'Missing typed API backend'
}
if (-not (Test-Path -LiteralPath $eventPath)) {
    throw 'Missing typed API event mapper'
}
$backend = Get-Content -Raw -LiteralPath $backendPath
$events = Get-Content -Raw -LiteralPath $eventPath
$all = $backend + $events

function Assert-Match([string]$text, [string]$pattern, [string]$message) {
    if ($text -notmatch $pattern) { throw $message }
}
function Assert-NoMatch([string]$text, [string]$pattern, [string]$message) {
    if ($text -match $pattern) { throw $message }
}

foreach ($request in @(
        'SET_POWER','SET_PROFILE_MASK','SET_NAME','SET_PIN','SET_SSP',
        'PAIR_CONFIRM','SET_DISCOVERABLE','SET_CONNECTABLE','SET_COD',
        'CLEAR_PEER_INDEX','CLEAR_PEER_ADDRESS','CLEAR_PEERS','SET_TDL',
        'SCAN_START','SCAN_STOP','DISCONNECT_ALL','CONNECT','CONNECT_LAST',
        'DISCONNECT_PROFILE','SET_HFP_CONFIG','HFP_DIAL','HFP_REDIAL',
        'HFP_DTMF','HFP_CONTROL','SET_MICROPHONE_MUTE',
        'SET_SPEAKER_VOLUME','SET_A2DP_MUTE','SET_AVRCP_CONFIG',
        'AVRCP_CONTROL','SET_REPEAT','SET_SHUFFLE','PBAP_SYNC',
        'PBAP_CANCEL','PBAP_AUTHENTICATE','PBAP_EVENT_SPACE_AVAILABLE',
        'PBAP_PEER_DISCONNECTED')) {
    Assert-Match $backend ("BT_XSTACK_REQUEST_" + $request) `
        "Missing backend request case: $request"
}

foreach ($native in @(
        'btstack_gap_set_power','btstack_gap_set_local_name',
        'btstack_gap_set_pin','btstack_gap_set_ssp_mode',
        'btstack_gap_pairing_confirm','btstack_gap_scan_start',
        'btstack_gap_scan_stop','btstack_hfp_hf_connect',
        'btstack_hfp_hf_control','btstack_a2dp_sink_connect',
        'btstack_avrcp_control',
        'btstack_pbap_client_sync','btstack_pbap_client_cancel',
        'btstack_pbap_client_authenticate',
        'btstack_pbap_client_peer_disconnected',
        'btstack_run_loop_gpcv2178_enqueue_callback')) {
    Assert-Match $backend ("\b" + $native + "\s*\(") `
        "Missing native backend call: $native"
}

foreach ($callback in @(
        'btstack_gap_set_event_callback',
        'btstack_hfp_hf_set_profile_event_callback',
        'btstack_a2dp_sink_set_event_callback',
        'btstack_avrcp_set_event_callback',
        'btstack_a2dp_sink_set_audio_sample_callback')) {
    Assert-Match $all ("\b" + $callback + "\s*\(") `
        "Missing native event callback registration: $callback"
}
Assert-Match $all '\bbtstack_pbap_client_set_event_callback\s*\(' `
    'Missing generic PBAP event callback registration'

foreach ($domain in @(
        'BT_XSTACK_EVENT_DOMAIN_SERVICE',
        'BT_XSTACK_EVENT_DOMAIN_CONNECTION',
        'BT_XSTACK_EVENT_DOMAIN_PHONE',
        'BT_XSTACK_EVENT_DOMAIN_AUDIO',
        'BT_XSTACK_EVENT_DOMAIN_PHONEBOOK')) {
    Assert-Match $events $domain "Missing typed event domain: $domain"
}

Assert-Match $backend 'bt_xstack_api_command_slots\s*\[' `
    'Backend must own fixed prepared-command slots'
Assert-NoMatch $backend 'bt_xstack_api_complete\s*\(' `
    'Backend must not synthesize an internal command-completion handshake'
Assert-NoMatch $all '\bbtstack_at_' `
    'Typed API backend must not depend on AT code'
Assert-NoMatch $all '\bmalloc\s*\(' `
    'Typed API backend must not allocate from the heap'

Write-Output 'xStack typed backend covers all current command and event domains'
