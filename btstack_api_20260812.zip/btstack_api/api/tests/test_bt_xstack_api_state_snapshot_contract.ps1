$ErrorActionPreference = 'Stop'

$apiRoot = Split-Path -Parent $PSScriptRoot
$internal = Get-Content -Raw -LiteralPath (Join-Path $apiRoot 'bt_xstack_api_internal.h')
$backend = Get-Content -Raw -LiteralPath (Join-Path $apiRoot 'bt_xstack_api_backend.c')
$events = Get-Content -Raw -LiteralPath (Join-Path $apiRoot 'bt_xstack_api_event.c')

if ($internal -notmatch '\bbt_xstack_api_state_set_value\s*\(') {
    throw 'Missing synchronized state update API'
}
if ($backend -match '\bbt_xstack_api_state_mutable\s*\(') {
    throw 'Backend must not mutate the shared state through a raw pointer'
}
if ($events -notmatch '(?s)bt_xstack_api_state_sync_gap\s*\([^)]*\).*?taskENTER_CRITICAL\s*\(\).*?taskEXIT_CRITICAL\s*\(\)') {
    throw 'GAP snapshot updates must be protected by a critical section'
}
if ($events -notmatch '(?s)bt_xstack_api_state_set_value\s*\([^)]*\).*?taskENTER_CRITICAL\s*\(\).*?taskEXIT_CRITICAL\s*\(\)') {
    throw 'Request-driven state updates must be protected by a critical section'
}
if ($events -notmatch '(?s)bt_xstack_api_backend_copy_state\s*\([^)]*\).*?taskENTER_CRITICAL\s*\(\).*?memcpy\s*\(.*?taskEXIT_CRITICAL\s*\(\)') {
    throw 'Synchronous Getter snapshots must copy under a critical section'
}

Write-Output 'xStack synchronous Getter state has protected readers and writers'
